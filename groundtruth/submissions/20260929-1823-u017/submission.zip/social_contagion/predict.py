import json
import math
from pathlib import Path
import numpy as np
FORMAT = 1

def _resolve(obj, arrays):
    if isinstance(obj, str) and obj.startswith('npz:') and (arrays is not None):
        return np.asarray(arrays[obj[4:]])
    if isinstance(obj, dict):
        return {k: _resolve(v, arrays) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_resolve(v, arrays) for v in obj]
    return obj

def load_doc(folder):
    folder = Path(folder)
    doc = json.loads((folder / 'model.json').read_text())
    npz = folder / 'model.npz'
    if npz.exists():
        with np.load(npz, allow_pickle=False) as z:
            arrays = {k: z[k] for k in z.files}
        doc = _resolve(doc, arrays)
    if int(doc.get('format', 1)) != FORMAT:
        raise ValueError('unsupported model.json format')
    return doc

def _bound_vec(vals, default):
    return np.array([default if v is None else float(v) for v in vals], dtype=float)

def clip_vectors(doc):
    p = len(doc['observables'])
    hlo = _bound_vec(doc.get('hard_lo', [0.0] * p), -np.inf)
    hhi = _bound_vec(doc.get('hard_hi', [None] * p), np.inf)
    clo = _bound_vec(doc.get('clip_lo', [None] * p), -np.inf)
    chi = _bound_vec(doc.get('clip_hi', [None] * p), np.inf)
    lo = np.maximum(hlo, clo)
    hi = np.minimum(hhi, chi)
    hi = np.maximum(hi, lo)
    return (lo, hi)

def finalize(Y, y0, lo, hi):
    Y = np.array(Y, dtype=float, copy=True)
    y0 = np.asarray(y0, dtype=float)
    fill_default = np.where(np.isfinite(lo), lo, np.where(np.isfinite(hi), hi, 0.0))
    ypers = np.where(np.isfinite(y0), y0, fill_default)
    ypers = np.minimum(np.maximum(ypers, lo), hi)
    bad = ~np.isfinite(Y)
    if bad.any():
        Y[bad] = np.broadcast_to(ypers, Y.shape)[bad]
    np.clip(Y, lo, hi, out=Y)
    return Y

def phi(Un, ps):
    Un = np.asarray(Un, dtype=float)
    cols = [Un]
    if ps.get('sq', True):
        cols.append(Un * Un)
    for i, j in ps.get('pairs', []):
        cols.append((Un[:, int(i)] * Un[:, int(j)])[:, None])
    if ps.get('const', True):
        cols.append(np.ones((Un.shape[0], 1)))
    return np.concatenate(cols, axis=1)

def _roll_ode(blob, doc, y0, U, ctx):
    core, fam = ode_modules(blob['family'], ctx.get('base_dir'), ctx.get('tag', ''))
    th = core.theta_dict(fam, [float(v) for v in blob['theta']])
    return core.rollout(fam, np.asarray(y0, float), U, th, frozenset(blob['mech']), n_sub=int(blob.get('n_sub', 4)))
_KINDS = {'ode': _roll_ode}

def _dispatch(blob, doc, y0, U, ctx):
    return _KINDS[blob['kind']](blob, doc, y0, U, ctx)

def rollout_from_blob(blob, y0, U, doc=None, base_dir=None, tag='', clip=True):
    if doc is None:
        doc = blob
    if 'model' in blob and 'observables' in blob:
        blob = blob['model']
    y0 = np.asarray(y0, dtype=float)
    U = np.atleast_2d(np.asarray(U, dtype=float))
    lo, hi = clip_vectors(doc)
    ctx = {'base_dir': base_dir, 'tag': tag, 'lo': lo, 'hi': hi}
    Y = _dispatch(blob, doc, y0, U, ctx)
    Y = np.asarray(Y, dtype=float).reshape(U.shape[0], len(doc['observables']))
    if not clip:
        return Y
    Y = finalize(Y, y0, lo, hi)
    return apply_post(doc, Y, U, y0)

def apply_post(doc, Y, U, y0=None):
    rules = doc.get('post') or []
    if not rules:
        return Y
    obs, ctrls = (list(doc['observables']), list(doc['controls']))
    for r in rules:
        if r.get('type') == 'le_control' and r.get('obs') in obs and (r.get('control') in ctrls):
            j, k = (obs.index(r['obs']), ctrls.index(r['control']))
            cap = U[:, k] * float(r.get('scale', 1.0))
            if r.get('lag'):
                cap = np.maximum(cap, np.concatenate([cap[:1], cap[:-1]]))
            Y[:, j] = np.minimum(Y[:, j], cap)
        elif r.get('type') == 'le_const' and r.get('obs') in obs:
            Y[:, obs.index(r['obs'])] = np.minimum(Y[:, obs.index(r['obs'])], float(r['value']))
        elif r.get('type') == 'ge_const' and r.get('obs') in obs:
            Y[:, obs.index(r['obs'])] = np.maximum(Y[:, obs.index(r['obs'])], float(r['value']))
        elif r.get('type') == 'exo_harmonic' and r.get('obs') in obs:
            j = obs.index(r['obs'])
            t = np.arange(Y.shape[0], dtype=float)
            cf = [float(v) for v in r.get('coef', [])]
            P = float(r['period'])
            out = np.full(Y.shape[0], cf[0] if cf else 0.0)
            for h in range((len(cf) - 1) // 2):
                w = 2.0 * np.pi * (h + 1) * t / P
                out = out + cf[1 + 2 * h] * np.sin(w) + cf[2 + 2 * h] * np.cos(w)
            Y[:, j] = out
        elif r.get('type') == 'integrate' and r.get('obs') in obs:
            j = obs.index(r['obs'])
            flow = np.full(Y.shape[0], float(r.get('bias', 0.0)))
            for name, cf in zip(r.get('src', []), r.get('coef', [])):
                if name in obs:
                    flow = flow + float(cf) * Y[:, obs.index(name)]
            lo_, hi_ = (float(r.get('lo', -np.inf)), float(r.get('hi', np.inf)))
            prev = float(y0[j]) if y0 is not None and np.isfinite(y0[j]) else float(Y[0, j])
            out = np.empty(Y.shape[0])
            for t in range(Y.shape[0]):
                prev = min(max(prev + flow[t], lo_), hi_)
                out[t] = prev
            Y[:, j] = out
    return Y

def _num(v, default):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    return f if math.isfinite(f) else default

def build_inputs(doc, initial, interventions):
    obs, ctrls = (doc['observables'], doc['controls'])
    lo, hi = clip_vectors(doc)
    y0 = np.array([_num(initial.get(o), np.nan) for o in obs], dtype=float)
    rec = doc.get('recovery', {})
    prev = [_num(rec.get(c), 0.5 * (doc['bounds'][c][0] + doc['bounds'][c][1])) for c in ctrls]
    U = np.empty((len(interventions), len(ctrls)))
    for t, a in enumerate(interventions):
        for i, c in enumerate(ctrls):
            v = _num(a.get(c), prev[i])
            b0, b1 = doc['bounds'][c]
            v = min(max(v, float(b0)), float(b1))
            U[t, i] = v
            prev[i] = v
    return (y0, U)

def predict_episode(doc, initial, interventions, context=None, base_dir=None, tag=''):
    if context is not None:
        fam = context.get('family')
        if fam is not None and fam != doc.get('system'):
            raise ValueError('model.json belongs to another system')
    y0, U = build_inputs(doc, initial, interventions)
    if not np.all(np.isfinite(y0)):
        raise ValueError('nonfinite initial observation')
    Y = rollout_from_blob(doc, y0, U, doc=doc, base_dir=base_dir, tag=tag)
    obs = doc['observables']
    names = list(initial.keys())
    cols = []
    for n in names:
        if n in obs:
            cols.append(Y[:, obs.index(n)].tolist())
        else:
            v = _num(initial.get(n), 0.0)
            cols.append([v] * U.shape[0])
    return [dict(zip(names, row)) for row in zip(*cols)] if names else [{} for _ in range(U.shape[0])]

def _ode_core():
    import numpy as np

    def theta_dict(mod, vec=None):
        names = [p[0] for p in mod.PARAMS]
        if vec is None:
            vec = [p[1] for p in mod.PARAMS]
        return dict(zip(names, (float(v) for v in vec)))

    def _clip(mod, x):
        lo = getattr(mod, 'STATE_LO', None)
        hi = getattr(mod, 'STATE_HI', None)
        x = np.maximum(x, 0.0 if lo is None else lo)
        if hi is not None:
            x = np.minimum(x, hi)
        return x

    def rollout(mod, y0, U, th, mech, n_sub=4, return_states=False):
        y0 = np.asarray(y0, dtype=float)
        U = np.asarray(U, dtype=float)
        mech = frozenset(mech)
        x = _clip(mod, np.asarray(mod.x0(y0, th, mech), dtype=float))
        T = U.shape[0]
        Y = np.empty((T, len(mod.OBS)))
        X = np.empty((T, x.size)) if return_states else None
        dt = 1.0 / n_sub
        f = mod.f
        for t in range(T):
            u = U[t]
            for _ in range(n_sub):
                k1 = f(x, u, th, mech)
                k2 = f(_clip(mod, x + 0.5 * dt * k1), u, th, mech)
                k3 = f(_clip(mod, x + 0.5 * dt * k2), u, th, mech)
                k4 = f(_clip(mod, x + dt * k3), u, th, mech)
                x = _clip(mod, x + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4))
            if not np.all(np.isfinite(x)):
                x = np.nan_to_num(x, nan=0.0, posinf=1000000.0, neginf=0.0)
            Y[t] = mod.h(x, u, th, mech)
            if return_states:
                X[t] = x
        return (Y, X) if return_states else Y

    class _Namespace_q7:
        pass
    _obj_q7 = _Namespace_q7()
    _obj_q7.__dict__.update(locals())
    return _obj_q7

def _ode_social_contagion_z20():
    import math
    import numpy as np
    FAMILY = 'social_contagion_z20'
    OBS = ['adopters_a', 'adopters_b']
    CTRL = ['seeding', 'incentive', 'bridge_outreach']
    MECHS = {'A': 'credibility erodes with promised waiting cohorts', 'B': 'incentive expectations: incentive-led members leave when incentive falls below memory', 'C': 'cross-community relationships built by introductions carry word of mouth'}
    N_SUB = 2
    _PER = ['L', 'M', 'X', 'D', 'W1', 'W2', 'W3', 'V1', 'V2', 'V3', 'K']
    STATE = [s + 'a' for s in _PER] + [s + 'b' for s in _PER] + ['E', 'R']
    _NS = len(STATE)
    STATE_LO = np.zeros(_NS)
    STATE_HI = np.array(([10000.0] * 10 + [1.0]) * 2 + [2.0, 1.0])
    R_MAX = 1.5
    PHI_HALF = 0.7
    TAU_K = 50.0
    TAU_R = 15.0
    PARAMS = [('N_a', 360.0, 60.0, 3000.0, True), ('N_b', 350.0, 40.0, 3000.0, True), ('s_a', 0.003, 0.0001, 1.0, True), ('s_b', 0.0008, 1e-05, 1.0, True), ('q', 0.015, 0.001, 1.5, True), ('o', 0.001, 1e-05, 0.1, True), ('tau_on', 9.0, 1.0, 60.0, True), ('c_L', 0.012, 0.0001, 0.5, True), ('k_X', 0.12, 0.005, 1.5, True), ('m0', 0.33, 0.0, 0.9, False), ('k_conv', 0.3, 0.0, 0.7, False), ('k_A', 0.1, 0.0, 3.0, False), ('k_B', 0.045, 0.0, 0.7, False), ('tau_E', 28.0, 1.0, 500.0, True), ('tau_D', 13.0, 1.0, 1000.0, True), ('k_inc', 0.8, 0.0, 3.0, False), ('k_inc_b', 0.8, 0.0, 3.0, False), ('s_xb', 0.001, 1e-06, 1.0, True), ('tau_on_b', 9.0, 1.0, 60.0, True)]

    class _PY:
        max = max
        min = min

        @staticmethod
        def sqrt(z):
            return math.sqrt(z) if z > 0.0 else 0.0

    class _NP:
        max = np.maximum
        min = np.minimum

        @staticmethod
        def sqrt(z):
            return np.sqrt(np.maximum(z, 0.0))

    def _pos(M, a, e):
        return 0.5 * (a + M.sqrt(a * a + e * e))

    def _unpack(x, u):
        if np.ndim(x) == 1:
            return (_PY, x.tolist(), np.asarray(u, dtype=float).tolist())
        return (_NP, [x[..., i] for i in range(x.shape[-1])], [u[..., j] for j in range(u.shape[-1])])

    def _pack(M, vals):
        if M is _PY:
            return np.array(vals, dtype=float)
        return np.stack(np.broadcast_arrays(*vals), axis=-1).astype(float)

    def _yunpack(y0):
        if np.ndim(y0) == 1:
            return (_PY, np.asarray(y0, dtype=float).tolist())
        return (_NP, [y0[..., j] for j in range(y0.shape[-1])])

    def _community(M, s, N, drive, th, inc, phi, boost, chM, mech, g):
        L, Mm, X, D, W1, W2, W3, V1, V2, V3, K = s
        A = L + Mm + X
        W = W1 + W2 + W3 + V1 + V2 + V3
        pool = _pos(M, N - A - W - D, 1.0)
        raw = (drive + th['q'] * A / N + th['o']) * boost
        if 'A' in mech:
            raw = raw * K
        r = raw / (1.0 + raw / R_MAX)
        new = r * pool
        k = 3.0 * g / th['tau_on']
        conv = th['k_conv'] * inc * L
        outL = th['c_L'] * L
        outM = chM * Mm
        outX = th['k_X'] * X
        dW1 = (1.0 - phi) * new - k * W1
        dW2 = k * (W1 - W2)
        dW3 = k * (W2 - W3)
        dV1 = phi * new - k * V1
        dV2 = k * (V1 - V2)
        dV3 = k * (V2 - V3)
        dL = k * W3 - outL - conv
        dM = k * V3 + conv - outM
        dX = -outX
        dD = outL + outM + outX - D / th['tau_D']
        if 'A' in mech:
            dK = (1.0 - K) / TAU_K - th['k_A'] * K * (V1 + V2 + V3) / N
        else:
            dK = 0.0 * K
        return [dL, dM, dX, dD, dW1, dW2, dW3, dV1, dV2, dV3, dK]

    def f(x, u, th, mech):
        M, s, uu = _unpack(x, u)
        seed, inc, br = uu
        n = len(_PER)
        sa, sb, E, R = (s[:n], s[n:2 * n], s[2 * n], s[2 * n + 1])
        chM = th['c_L'] + 0.0 * E
        dE = 0.0 * E
        if 'B' in mech:
            chM = th['c_L'] + th['k_B'] * _pos(M, E - inc, 0.05)
            dE = (inc - E) / th['tau_E']
        phi = inc / (inc + PHI_HALF)
        boost = 1.0 + th['k_inc'] * phi
        boost_b = 1.0 + th['k_inc_b'] * phi
        loc = seed * _pos(M, 1.0 - br, 0.01)
        Aa = sa[0] + sa[1] + sa[2]
        Ab = sb[0] + sb[1] + sb[2]
        dra = th['s_a'] * loc
        drb = th['s_b'] * loc
        dR = 0.0 * R
        if 'C' in mech:
            drb = drb + th['s_xb'] * 10.0 * R
            dR = (seed * br / 10.0 - R) / TAU_R
        else:
            drb = drb + th['s_xb'] * seed * br
        g = 1.0
        da = _community(M, sa, th['N_a'], dra, th, inc, phi, boost, chM, mech, g)
        db = _community(M, sb, th['N_b'], drb, th, inc, phi, boost_b, chM, mech, g * th['tau_on'] / th['tau_on_b'])
        return _pack(M, da + db + [dE, dR])

    def h(x, u, th, mech):
        M, s, uu = _unpack(x, u)
        n = len(_PER)
        return _pack(M, [s[0] + s[1] + s[2], s[n] + s[n + 1] + s[n + 2]])

    def x0(y0, th, mech):
        M, y = _yunpack(y0)
        a = M.max(y[0], 0.0)
        b = M.max(y[1], 0.0)
        m0 = th['m0']
        z = 0.0 * a + 0.0 * m0
        one = z + 1.0
        return _pack(M, [(1.0 - m0) * a, z, m0 * a, z, z, z, z, z, z, z, one, (1.0 - m0) * b, z, m0 * b, z, z, z, z, z, z, z, one, z, z])

    class _Namespace_q7:
        pass
    _obj_q7 = _Namespace_q7()
    _obj_q7.__dict__.update(locals())
    return _obj_q7
_ODE_BUILD = {'social_contagion_z20': _ode_social_contagion_z20}
_ODE_MODS = {}

def ode_modules(family, base_dir=None, tag=''):
    if family not in _ODE_MODS:
        _ODE_MODS[family] = (_ode_core(), _ODE_BUILD[family]())
    return _ODE_MODS[family]
SYSTEM = 'social_contagion'
HARD = {'adopters_a': [0.0, None], 'adopters_b': [0.0, None]}
_HERE = Path(__file__).resolve().parent
_DOC = {}

def _get_doc():
    if 'doc' not in _DOC:
        _DOC['doc'] = load_doc(_HERE)
    return _DOC['doc']

def _fnum(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return 0.0
    return f if math.isfinite(f) else 0.0

def _persistence(initial, n, names):
    row = {}
    for k in names:
        v = _fnum(initial.get(k)) if isinstance(initial, dict) else 0.0
        lo, hi = HARD.get(k, (0.0, None))
        if lo is not None and v < lo:
            v = float(lo)
        if hi is not None and v > hi:
            v = float(hi)
        row[k] = v
    return [dict(row) for _ in range(n)]

def _names(initial, context):
    names = list(initial.keys()) if isinstance(initial, dict) else []
    try:
        for k in context.get('observables', []) or []:
            if k not in names:
                names.append(k)
    except Exception:
        pass
    return names

def _valid(out, n, names):
    if not isinstance(out, list) or len(out) != n:
        return False
    for row in out:
        if not isinstance(row, dict) or len(row) != len(names):
            return False
        for k in names:
            v = row.get(k)
            if not isinstance(v, float) or not math.isfinite(v):
                return False
    return True

def predict(initial, interventions, context):
    try:
        n = len(interventions)
    except Exception:
        n = 4000
    try:
        names = _names(initial, context)
    except Exception:
        names = []
    try:
        doc = _get_doc()
        init = {k: initial.get(k, 0.0) for k in names}
        out = predict_episode(doc, init, interventions, context, base_dir=_HERE, tag=SYSTEM)
        if _valid(out, n, names):
            return out
    except Exception:
        pass
    return _persistence(initial, n, names)
